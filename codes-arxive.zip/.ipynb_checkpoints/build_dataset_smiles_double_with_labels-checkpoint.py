import pandas as pd
import numpy as np
from rdkit import Chem
from rdkit.Chem import AllChem
from datasets import Dataset
import itertools
from sklearn.model_selection import train_test_split
import gc
import itertools

print("import completed")

df0 = pd.read_csv("/home/u111169/wrkdir/mgh-project/ChemAP/dataset/DrugApp/All_training_feature_vectors.csv")

print("dataframe created")

df=df0[["SMILES",	"Label"]]

# def morgan_fn(smile):
#     mol = Chem.MolFromSmiles(smile)
#     morgan_fp = AllChem.GetMorganFingerprintAsBitVect(mol, useChirality=True, radius=2, nBits=2048)
#     morgan = ''.join(str(int(bit)) for bit in morgan_fp)
#     return morgan

# df["morgan"] = df["SMILES"].map(morgan_fn)
# df=df[["morgan" , "Label"]]

print("SMILES dataframe created")
test_size = 0.2
val_size = 0.5
train_df , temp = train_test_split(df , stratify = df.Label , test_size = test_size , random_state=1234)
test_df , val_df = train_test_split(temp , stratify = temp.Label , test_size = val_size , random_state=1234)


#-----------------------------------
# reset index
train_df.reset_index(drop=True, inplace=True)
val_df.reset_index(drop=True, inplace=True)
#test_df.reset_index(drop=True, inplace=True)

def duable_maker_with_label(df):
    pos_df = df[df["Label"]==0]["SMILES"]
    neg_df = df[df["Label"]==1]["SMILES"]
    elements = pos_df.tolist()
    elements_neg = neg_df.tolist()
    tuple_length = 2
    unique_tuples = list(itertools.combinations(elements, tuple_length))
    unique_tuples_neg = list(itertools.combinations(elements_neg, tuple_length))
    ll = unique_tuples + unique_tuples_neg
    df1 = pd.DataFrame(unique_tuples, columns=['Column1', 'Column2'])
    df2 = pd.DataFrame(unique_tuples, columns=['Column1', 'Column2'])
    combined_df = pd.concat([df1, df2], ignore_index=True)
    combined_df["label"]=1
    unique_tuples = set(itertools.product(elements, elements_neg))
    unique_tuples_list = list(unique_tuples)
    df3 = pd.DataFrame(unique_tuples_list, columns=['Column1', 'Column2'])
    df3["label"]=0 
    combined_df_f = pd.concat([combined_df, df3], ignore_index=True)
    return combined_df_f


duable_with_label = duable_maker_with_label(train_df)
train_dataset = Dataset.from_pandas(duable_with_label)
print("training doubles  created. ")
train_dataset.save_to_disk("/home/u111169/wrkdir/mgh-project/datasets/training_double_with_label")
print("datasets saved at the local destination. ")
gc.collect()

val_df_d = duable_maker_with_label(val_df)
val_dataset = Dataset.from_pandas(val_df_d)
print("validation double  created. ")
val_dataset.save_to_disk("/home/u111169/wrkdir/mgh-project/datasets/validation_double_with_label")
print("datasets saved at the local destination. ")
gc.collect()

print("Finished !")
