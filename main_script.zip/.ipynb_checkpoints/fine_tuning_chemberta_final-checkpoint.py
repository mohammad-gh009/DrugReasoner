import random
from training_util import * 
from ImportsAndDatasets import *
torch.manual_seed(42)
np.random.seed(42)
random.seed(42)

print("Imports completed")
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

df = pd.read_csv("/home/u111169/wrkdir/mgh-project/ChemAP/dataset/DrugApp/All_training_feature_vectors.csv")
df["SMILES"] = df["SMILES"].apply(lambda x: get_canonical_smiles(x))
df.rename(columns={"Label":"labels"}, inplace=True)

train_df , val_df , test_df , dataset_train , dataset_df , dataset_test= train_valid_test_split(df[["SMILES" , "labels"]])


tokenizer = RobertaTokenizer.from_pretrained("/home/u111169/.cache/huggingface/hub/models--DeepChem--ChemBERTa-77M-MTR/snapshots/66b895cab8adebea0cb59a8effa66b2020f204ca")#'FacebookAI/xlm-roberta-large'
model = RobertaForSequenceClassification.from_pretrained("/home/u111169/.cache/huggingface/hub/models--DeepChem--ChemBERTa-77M-MTR/snapshots/66b895cab8adebea0cb59a8effa66b2020f204ca" ,num_labels=2)

model.config.classifier_dropout=0.01

def tokenize_function(examples):
    return tokenizer(examples['SMILES'], padding="max_length" , truncation=True )#,max_length=166

tokenized_train = dataset_train.map(tokenize_function)
tokenized_val = dataset_df.map(tokenize_function)
tokenized_test = dataset_test.map(tokenize_function)

class_weights = torch.tensor([len(train_df[train_df["labels"] == i]) / len(train_df) for i in np.unique(train_df["labels"])]).to(device)

class CustomLoss(nn.Module):
    def __init__(self, class_weights):
        super(CustomLoss, self).__init__()
        self.ce_loss = nn.CrossEntropyLoss(weight=class_weights)

    def forward(self, logits, labels):
        ce_loss = self.ce_loss(logits, labels)
        l1_loss = torch.mean(torch.abs(logits))
        return ce_loss + 0.1 * l1_loss

class CustomTrainer(Trainer):
    def compute_loss(self, model, inputs, return_outputs=False, num_items_in_batch=None):
        labels = inputs.pop("labels")
        outputs = model(**inputs)
        logits = outputs.logits
        loss_fn = CustomLoss(class_weights)
        loss = loss_fn(logits, labels)
        return (loss, outputs) if return_outputs else loss
        
        
        
training_args = TrainingArguments(
    output_dir='/home/u111169/wrkdir/mgh-project/checkpoints/fine_tuning_chemberta_final_chemapp_dataset/overfitted',
    num_train_epochs= 200,
    evaluation_strategy='steps',
    save_strategy='steps',
    learning_rate=2e-3,
    per_device_train_batch_size=128,
    per_device_eval_batch_size=128,
    save_steps=10,
    eval_steps=10,
    save_total_limit=30,
    gradient_accumulation_steps=1,
    eval_accumulation_steps=1,
    do_eval=True,
    do_train=True,
    weight_decay=0.1,
    logging_dir = '/home/u111169/wrkdir/mgh-project/checkpoints/fine_tuning_chemberta_final_chemapp_dataset/overfitted/logs',
    logging_strategy="steps",
    logging_steps = 5,
    dataloader_drop_last=True,
    save_safetensors=False,
    adam_epsilon=1e-08,
    warmup_steps=100,
    seed=42,
    lr_scheduler_type='cosine',
    load_best_model_at_end = True,
    label_smoothing_factor=0.01,
    report_to = "none"
)


trainer = CustomTrainer(
    model=model,
    args=training_args,
    train_dataset=tokenized_train,
    eval_dataset=tokenized_val,
    tokenizer = tokenizer,
    # callbacks=[EarlyStoppingCallback(early_stopping_patience=2)]
)
trainer.train()#resume_from_checkpoint = True