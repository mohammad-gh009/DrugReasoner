import pandas as pd
from ImportsAndDatasets import *
import random

def get_fp(smiles):
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        raise ValueError("Invalid SMILES")

    # Generate Morgan fingerprint (radius=2, 2048-bit vector)
    fp = AllChem.GetMorganFingerprintAsBitVect(mol, radius=2, nBits=2048)

    # Convert to a bit string or list
    bit_string = fp.ToBitString()
    # bit_list = list(fp)
    return bit_string

def get_all_non_canonicals(original_smiles): 
    mol = Chem.MolFromSmiles(original_smiles)
    if mol is None:
        print("Invalid SMILES")
    else:
        num_atoms = mol.GetNumAtoms()
        seen = set()
        # Generate multiple non-canonical SMILES
        for _ in range(1000):  # Adjust iterations for more coverage
            new_order = list(range(num_atoms))
            random.shuffle(new_order)
            randomized_mol = Chem.RenumberAtoms(mol, new_order)
            randomized_smiles = Chem.MolToSmiles(randomized_mol, canonical=False)
            if randomized_smiles not in seen:
                seen.add(randomized_smiles)
    return list(seen)

def df2noncanonical(df): 
    f_l = []
    for n , i in df["SMILES"].items(): 
        df_c = pd.DataFrame()
        df_c["SMILES"] = get_all_non_canonicals(i)
        df_c["labels"] = df["labels"][n]
        f_l.append(df_c)
    df_train_with_noncanonicals = pd.concat(f_l , axis=0)
    
    return df_train_with_noncanonicals

def df2noncanonical(df): 
    f_l = []
    for n , i in df["SMILES"].items(): 
        df_c = pd.DataFrame()
        df_c["SMILES"] = get_all_non_canonicals(i)
        df_c["labels"] = df["labels"][n]
        f_l.append(df_c)
    df_train_with_noncanonicals = pd.concat(f_l , axis=0)
    
    return df_train_with_noncanonicals

def df2noncanonical_only_approved(df): 
    df_filtered = df[df["labels"] == 1]
    f_l = []
    for n , i in df_filtered["SMILES"].items(): 
        df_c = pd.DataFrame()
        df_c["SMILES"] = get_all_non_canonicals(i)
        df_c["labels"] = df["labels"][n]
        f_l.append(df_c)
    df_train_with_noncanonicals = pd.concat(f_l , axis=0)
    df_final = pd.concat([df_train_with_noncanonicals ,df[df["labels"] == 0] ], axis=0)
    
    return df_final