#!/opt/perl/5.16.3/bin/perl -w

use strict;
use warnings;
use LWP::UserAgent;


###=============================================================================###
###  Get a concise data table for assays performed against a given gene target. ###
###=============================================================================###

my $geneid      =  "25279";

my $pugrest     =  "https://pubchem.ncbi.nlm.nih.gov/rest/pug";
my $input       =  "assay/target/geneid/$geneid";
my $operation   =  "concise";
my $output      =  "CSV";
my $pug_url     =  "$pugrest/$input/$operation/$output";

my $ua          =  new LWP::UserAgent;
my $req         =  new HTTP::Request GET => "$pug_url";
my $response    =  $ua->request($req);
my $header      =  $response->headers_as_string;


print "###=============================###\n";
print "###  Throttling Control Status  ###\n";
print "###=============================###\n\n";

open my $filehandle, "<", \$header;

while(<$filehandle>) {

    print $_ if ( $_ =~ m|X-Throttling-Control| ) ;

}

close $filehandle;

print "\n\n";


print "###===================###\n";
print "###  PUG-REST Output  ###\n";
print "###===================###\n\n";

print $response->content;


