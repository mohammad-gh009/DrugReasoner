#!/opt/perl/5.16.3/bin/perl -w

use strict;
use warnings;
use LWP::UserAgent;

my $pugrest    =  "https://pubchem.ncbi.nlm.nih.gov/rest/pug";

my $input      =  "compound/fastidentity/inchi";
my $operation  =  "property/inchikey,inchi";
my $output     =  "csv";
my $options    =  "identity_type=same_connectivity";

my $inchi      =  "InChI=1S/C5H5N5O/c6-5-9-3-2(4(11)10-5)7-1-8-3/h1H,(H4,6,7,8,9,10,11)";


#-- Assemble the PUG-REST URL as an HTTP POST call.

my $url        = "$pugrest/${input}/${operation}/${output}?${options}";

my $url_params = "inchi=$inchi";


#-- Create HTTP user agent.

my $ua = new LWP::UserAgent;


#-- Create HTTP request object.

my $req = new HTTP::Request POST => "$url";
$req->content_type('application/x-www-form-urlencoded');
$req->content("$url_params");


#-- Post the HTTP request.

my $response = $ua->request($req); 

print $response->content;

