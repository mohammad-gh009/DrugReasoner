#!/opt/perl/5.16.3/bin/perl -w

use strict;
use warnings;
use LWP::Simple;
use LWP::UserAgent;

my ( $sdf, $thresh ) = ( "example04.sdf", "95" );

my $pugrest     =  "https://pubchem.ncbi.nlm.nih.gov/rest/pug";
my $input       =  "compound/fastsimilarity_2d/sdf";
my $operation   =  "cids";
my $output      =  "txt";
my $options     =  "Threshold=$thresh";


#--  Read data from the SDF file.

my $data;

open(SDF,$sdf) || die "Can't open file $sdf for reading: $!\n";

while(<SDF>) {
    $data .= $_;
}

close(SDF) || die "Can't close file $sdf: $!\n";


#-- Assemble the PUG-REST URL as an HTTP POST call.

my $url = "$pugrest/$input/$operation/$output?$options";

my $url_params =
       '--AaB03x'                                   . "\r\n"
     . 'Content-Disposition: form-data; name="sdf"' . "\r\n"
     . 'Content-Type: text/plain'                   . "\r\n"
     . ''                                           . "\r\n"
     . "$data"                                      . "\r\n"
     . '--AaB03x--'                                 . "\r\n";


#-- Create HTTP user agent & POST request objects.

my $ua = new LWP::UserAgent;

my $req = new HTTP::Request POST => "$url";
$req->content_type('multipart/form-data; boundary=AaB03x');
$req->content("$url_params");


#-- Post the HTTP request.

my $response = $ua->request($req); 

print $response->content;
