#!/opt/perl/5.16.3/bin/perl -w

use strict;
use warnings;
use LWP::Simple;
use LWP::UserAgent;


###===================================================================###
###  Perform a 2-D similarity search using the input CID as a query,  ### 
###  and store the hits in a list key.                                ###
###===================================================================###

my  $cid  =  446157;

my  $pugrest     =  "https://pubchem.ncbi.nlm.nih.gov/rest/pug";
my  $input       =  "compound/fastsimilarity_2d/cid/$cid";
my  $operation   =  "cids";
my  $output      =  "TXT";
my  $pug_url     =  "$pugrest/$input/$operation/$output?Threshold=95&list_return=listkey";

my  $listkey     =  get( $pug_url );

print  "#-- List Key : ", $listkey, "\n";


###==========================================================================###
###  Convert the list key into the three parameters for an Entrez history .  ###
###==========================================================================###

my  $action    =  "pug_to_entrez";
my  $lg_cgi    =  "https://pubchem.ncbi.nlm.nih.gov/list_gateway/list_gateway.cgi";
my  $lg_url    =  "$lg_cgi" . "?action=$action" . "&pug_listkey=$listkey";

my  $lg_result =  get( $lg_url );



###==================================================================###
###  Parsing the XML file containing the Entrez history parameters.  ###
###==================================================================###

my  $filehandle;
my  $ListSize;
my  $db;
my  $QueryKey;
my  $WebEnv;

open $filehandle, "<", \$lg_result;

while(<$filehandle>) {

    $ListSize = $1 if ( $lg_result =~ m|<Response_list-size>(\d+)</Response_list-size>| );
    $db       = $1 if ( $lg_result =~ m|<Response_entrez-db>(\S+)</Response_entrez-db>| );
    $QueryKey = $1 if ( $lg_result =~ m|<Response_entrez-query-key>(\d+)</Response_entrez-query-key>| );
    $WebEnv   = $1 if ( $lg_result =~ m|<Response_entrez-webenv>(\S+)</Response_entrez-webenv>| ); 

}

close $filehandle;

print  "#-- List Size : ", $ListSize, "\n";
print  "#-- DB        : ", $db, "\n";
print  "#-- Query Key : ", $QueryKey, "\n";
print  "#-- WebEnv    : ", $WebEnv, "\n";



###========================================================================###
###  Get CIDs that satisfy Lipinski's rules of 5, using E-Util's esearch.  ###
###========================================================================###

my $query   = '"lipinski rule of 5"[Filter]';

my $eutils  = "https://www.ncbi.nlm.nih.gov/entrez/eutils";
my $esearch = "$eutils/esearch.fcgi" . "?db=$db"
                                     . "&term=$query"
                                     . "&retmax=1000" 
                                     . "&usehistory=y"
                                     . "&query_key=$QueryKey"
                                     . "&WebEnv=$WebEnv"  ;

my $esearch_result = get( $esearch );

print  "\n\n#-- BEGINNING OF THE XML OUTPUT\n\n";

print  $esearch_result;

print  "\n\n#-- END OF THE XML OUTPUT\n\n"
