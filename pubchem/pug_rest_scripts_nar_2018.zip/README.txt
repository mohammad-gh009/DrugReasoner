###############################################################################
#                                                                             #
#                     LIST OF EXAMPLE PERL SCRIPTS FOR                        #
#               PROGRAMMATIC ACCESS TO PUBCHEM THROUGH PUG-REST               #
#                                                                             #
###############################################################################


*
*  example01.pl (Simple, procedural approach)
*---------------------------------------------

    - Downloads compounds tested to be active in a given assay.
    - Uses the LWP::Simple module, which provides a simple procedural interface
      to the World Wide Web


*
*  example02.pl (Object-oriented approach)
*------------------------------------------

    - Downloads a concise data table for assays performed against a given gene
      target.
    - Uses an object-oriented approach by using the LWP::UserAgent module.


*
*  example03.pl (Inputs with special characters)
*------------------------------------------------

    - Performs an identity search using an InChI string as a query, and download
      the InChI and InChIKey for the returned hits.
    - Demonstrates how to make a PUG-REST request via HTTP HOST, when the query
      contains special characters (e.g., "/"), which are not compatible with
      the syntax of PUG-REST request URLs.


*
*  example04.pl (Multi-line input)
*----------------------------------

    - Performs a 2-D similarity search using the structure in a Structure-Data 
      File (example04.sdf) as a query, and downloads the CIDs of the hit 
      compounds.
    - Demonstrates how to make a PUG-REST request via HTTP HOST, when the query
      is a multi-line string (e.g., a SDF file).


*    
*  example05.pl (List Gateway: E-Utilities to PUG-REST)
*-------------------------------------------------------

    - Retrieves compounds whose molecular weights are within a given range
      (using E-Utilities), and download their molecular properties (through 
      through PUG-REST).
    - Demonstrate how to use the list from an Entrez E-search as an input for
      a subsequent PUG-REST request.

*
*  example06.pl (List Gateway: PUG-REST to E-Utilities)
*-------------------------------------------------------

    - Performs a 2-D similarity search for a CID query (through PUG-REST), and
      extract those that satisfy Lipinski's rule of 5 from the returned hits
      (through E-Utilities).


*
*  example07.pl (Throttling control status check)
*-------------------------------------------------

    - Download a concise data table for an AID input.
    - Demonstrate how to check the dynamic throttling control status.


