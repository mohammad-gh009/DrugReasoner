#!/opt/perl/5.16.3/bin/perl -w

use strict;
use warnings;
use LWP::UserAgent;


###=============================================================================###
###  Get a concise data table for assays performed against a given gene target. ###
###=============================================================================###

my $genesymbol  =  "RARA";

my $pugrest     =  "https://pubchem.ncbi.nlm.nih.gov/rest/pug";
my $input       =  "assay/target/genesymbol/$genesymbol";
my $operation   =  "aids";
my $output      =  "XML";
my $pug_url     =  "$pugrest/$input/$operation/$output";

my $ua          =  new LWP::UserAgent;
my $req         =  new HTTP::Request GET => "$pug_url";
my $response    =  $ua->request($req);

print $response->content;



