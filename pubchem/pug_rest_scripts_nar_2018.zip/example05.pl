#!/opt/perl/5.16.3/bin/perl -w

use  strict;
use  warnings;
use  LWP::Simple;


###==========================================================================###
###  Get CIDs whose Mol. Wt. is between two values, using E-Util's esearch.  ###
###==========================================================================###

my  $db       =  "pccompound";
my  $mw_min   =  249.99;
my  $mw_max   =  250.01;
my  $query    =  "$mw_min" . ":" . "$mw_max" . "[MolecularWeight]";

my  $eutils   =  "http://www.ncbi.nlm.nih.gov/entrez/eutils";
my  $esearch  =  "$eutils/esearch.fcgi?db=$db&term=$query&retmax=0&usehistory=y" ;

my  $esearch_result = get( $esearch );

$esearch_result =~ m|<Count>(\d+)</Count>.*<QueryKey>(\d+)</QueryKey>.*<WebEnv>(\S+)</WebEnv>|s;

my $ListSize = $1;
my $QueryKey = $2;
my $WebEnv   = $3;

print "#-- List Size = $ListSize\n";
print "#-- QueryKey  = $QueryKey\n";
print "#-- WebEnv    = $WebEnv\n";



###===========================================================###
###  Convert the Entrez history into a listkey for PUG-REST.  ###
###===========================================================###

my  $action    = "entrez_to_pug";
my  $lg_cgi    = "https://pubchem.ncbi.nlm.nih.gov/list_gateway/list_gateway.cgi?";
my  $lg_url    = "$lg_cgi" . "action=$action" . "&entrez_db=$db" . "&entrez_query_key=$QueryKey" . "&entrez_webenv=$WebEnv";
my  $lg_result = get( $lg_url );

$lg_result =~ m|<Response_pug-listkey>(\d+)</Response_pug-listkey>|s;

my  $listkey = $1;

print "\n";
print "#-- PUG-REST List Key  = $listkey\n\n";



###====================================================================###
###  Perform a 2-D similarity search against the CIDs in the listkey.  ###
###====================================================================###

my  $pugrest    = "https://pubchem.ncbi.nlm.nih.gov/rest/pug";

my  $input      = "compound/listkey/$listkey";
my  $operation  = "Property/MolecularFormula,MolecularWeight,ExactMass,MonoisotopicMass,IsotopeAtomCount,CovalentUnitCount,IsomericSMILES";
my  $output     = "CSV";

my  $pug_url    = "$pugrest/$input/$operation/$output";
my  $pug_result = get( $pug_url );


print  $pug_result;

