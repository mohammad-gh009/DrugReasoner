#!/opt/perl/5.16.3/bin/perl -w

use strict;
use warnings;
use LWP::Simple;


###============================================================###
###  Retrieve compounds tested to be active in a given assay.  ###
###============================================================###

my $aid  =  1259344;

my $pugrest     =  "https://pubchem.ncbi.nlm.nih.gov/rest/pug";

my $input       =  "assay/aid/$aid";
my $operation   =  "cids";
my $output      =  "TXT";
my $option      =  "cids_type=active";

my $pug_url     =  "$pugrest/$input/$operation/$output?$option";
my $pug_result  =  get( $pug_url );

print $pug_result, "\n";



